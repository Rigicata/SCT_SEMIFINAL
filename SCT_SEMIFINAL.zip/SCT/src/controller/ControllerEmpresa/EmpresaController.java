/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerEmpresa;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import model.Contrato;
import model.Empresa;
import model.Funcionario;
import modelDAO.ContratoDAO;
import modelDAO.EmpresaDAO;
import modelDAO.FuncionarioDAO;
import views.ViewsContrato.TelaAtualizarContratoVIEW;
import views.ViewsContrato.TelaContratoVIEW;
import views.ViewsContrato.TelaExcluirContratoVIEW;
import views.ViewsEmpresa.TelaAtualizarEmpresaVIEW;
import views.ViewsEmpresa.TelaAtualizarSenhaEmpresaVIEW;
import views.ViewsEmpresa.TelaLoginEmpresaVIEW;
import views.ViewsEmpresa.TelaMenuEmpresaVIEW;
import views.ViewsFuncionario.TelaAtualizarFuncionarioVIEW;
import views.ViewsFuncionario.TelaCadastrarFuncionarioVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;
import views.ViewsFuncionario.TelaConsultarFuncionarioVIEW;

/**
 *
 * @author aluno
 */
public class EmpresaController extends MouseAdapter {
    
    TelaLoginEmpresaVIEW TLE = new TelaLoginEmpresaVIEW();
    EmpresaDAO eDAO = new EmpresaDAO();
    TelaMenuEmpresaVIEW TME = new TelaMenuEmpresaVIEW();
    FuncionarioDAO fDAO = new FuncionarioDAO();
    ContratoDAO cDAO = new ContratoDAO();
    
    public EmpresaController(TelaLoginEmpresaVIEW TLE) {
        this.TLE = TLE;
        
    }
    
    @Override
    
    public void mouseClicked(MouseEvent e) {

        //VERIFICANDO A SENHA E O LOGIN
        Empresa empresa = eDAO.verificarLogin();
        if (e.getSource() == TLE.Painel_Entrar) {
            
            if (empresa.getCnpj().equals(TLE.ftCNPJ.getText()) && empresa.getSenha().equals(TLE.txtSenha.getPassword())) {
                TME.setVisible(true);
                this.TLE.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Login ou senha incorretos");
                
            }

            //MENU PRINCIPAL CLICANDO EM FUNCIONARIO
            if (e.getSource() == TME.Painel_Funcionario) {
                TelaConsultarFuncionarioVIEW TCONF = new TelaConsultarFuncionarioVIEW();
                TCONF.setVisible(true);
                this.TME.dispose();
                preencheTabelaCompleta(TCONF.tb_Funcionario);//TABELA JÁ PREENCHIDA QUANDO ENTRA
                // PARA PESQUISAR UM FUNCIONARIO ESPECIFICO
                if (e.getSource() == TCONF.pesquisar) {
                    Funcionario funcionario = fDAO.consultarFuncionarioCpf();
                    if (TCONF.ftCPF.getText() == funcionario.getCpf()) {
                        preencheTabelaporCPF(TCONF.tb_Funcionario);
                    } else {
                        JOptionPane.showMessageDialog(null, "Esse CPF não consta");
                    }

                    //REFERENTE A TELA DE ATUALIZAÇÃO DO FUNCIONÁRIO
                } else if (e.getSource() == TCONF.Painel_Atualizar) {
                    TelaAtualizarFuncionarioVIEW TAF = new TelaAtualizarFuncionarioVIEW();
                    TAF.setVisible(true);
                    TCONF.dispose();
                    if (e.getSource() == TAF.pesquisar) {
                        Funcionario funcionario = fDAO.consultarFuncionarioCpf();
                        if (TCONF.ftCPF.getText() == funcionario.getCpf()) {
                            preencheCamposFuncionario(TAF);
                            if (e.getSource() == TAF.Panel_Atualizar) {
                                fDAO.atualizarFuncionario(funcionario);
                            } else if (e.getSource() == TAF.Panel_Excluir) {
                                fDAO.excluirFuncionario(funcionario);
                                
                            } else {
                                JOptionPane.showMessageDialog(null, "ESSE CPF NAO CONSTA");
                            }
                        }

                        //CADASTRANDO UM USUÁRIO     
                    } else if (e.getSource() == TCONF.Painel_Cadastrar) {
                        TelaCadastrarFuncionarioVIEW TCADF = new TelaCadastrarFuncionarioVIEW();
                        TCADF.setVisible(true);
                        TCONF.dispose();
                        Funcionario funcionario = new Funcionario();
                        funcionario.setBairro(TCADF.txtBairro.getText());
                        funcionario.setCelular(TCADF.ftCelular.getText());
                        funcionario.setCep(TCADF.ftCep.getText());
                        funcionario.setCidade(TCADF.txtCidade.getText());
                        funcionario.setComplemento(TCADF.txtComplemento.getText());
                        funcionario.setCpf(TCADF.ftCPF.getText());
                        funcionario.setEmail(TCADF.txtEmail.getText());
                        funcionario.setEndereco(TCADF.txtEndereco.getText());
                        funcionario.setEstado(TCADF.txtEstado.getText());
                        funcionario.setNascimento(TCADF.ftNascimento.getText());
                        funcionario.setNome(TCADF.txtNomeFuncionario.getText());
                        funcionario.setNumero(TCADF.ftCelular.getText());
                        funcionario.setRg(TCADF.ftRg.getText());
                        funcionario.setSenha(TCADF.txtSenha.getText());
                        funcionario.setSexo(TCADF.combo_sexo.getSelectedItem().toString());// VER ISSO
                        funcionario.setTelefone(TCADF.ftTelefoneFixo.getText());
                        fDAO.cadastrarFuncionario(funcionario);

                        //CASO CLIQUE NA EMPRESA  
                    } else if (e.getSource() == TME.Painel_Empresa) {
                        TelaAtualizarEmpresaVIEW TAE = new TelaAtualizarEmpresaVIEW();
                        TAE.setVisible(true);
                        TME.dispose();
                        //PESQUISANDO CNPJ
                        if (e.getSource() == TAE.pesquisar) {
                            Empresa em = eDAO.consultarEmpresa();
                            if (TAE.ftCNPJ.getText() == em.getCnpj()) {
                                preencheCamposEmpresa(TAE);
                                //CASO QUEIRA ATUALIZAR OS CAMPOS
                                if (e.getSource() == TAE.Panel_Atualizar) {
                                    eDAO.atualizarEmpresa(empresa);
                                    //CASO QUEIRA ATUALIZAR A SENHA
                                } else if (e.getSource() == TAE.Panel_Senha) {
                                    TelaAtualizarSenhaEmpresaVIEW TASE = new TelaAtualizarSenhaEmpresaVIEW();
                                    TASE.setVisible(true);
                                    TAE.dispose();
                                    if (e.getSource() == TASE.Panel_Atualizar) {
                                        if (TASE.txtSenhaAntiga != TASE.txtSenhaNova) {
                                            empresa.setSenha(TASE.txtSenhaNova.getText());
                                            eDAO.mudarSenha(empresa);
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Senha nova tem que ser diferente da Senha Antiga");
                                        }
                                        
                                    }
                                    
                                } else {
                                    JOptionPane.showMessageDialog(null, "CNPJ NÃO CONSTA");
                                }
                                
                            } else if (e.getSource() == TME.Painel_Contrato) {
                                TelaContratoVIEW TC = new TelaContratoVIEW();
                                TC.setVisible(true);
                                TME.dispose();
                                if (e.getSource() == TC.Panel_Cadastrar) {
                                    Contrato contrato = new Contrato();
                                    contrato.setId(Integer.parseInt(TC.txtIdContrato.getText()));
                                    contrato.setClausula(TC.txtClausula.getText());
                                    contrato.setCnpj_Empresa(TC.ftCNPJ.getText());
                                    contrato.setCpf_Funcionario(TC.ftCPF.getText());
                                    contrato.setDiafinal(((JTextField) TC.djDiaFinal.getDateEditor().getUiComponent()).getText());
                                    contrato.setDiaincial(((JTextField) TC.djDiaInicial.getDateEditor().getUiComponent()).getText());
                                    contrato.setHorarioinicial(TC.ftHoraInicial.getText());
                                    contrato.setHorariofinal(TC.ftHoraFinal.getText());
                                    contrato.setLocalizacao(TC.txtLocal.getText());
                                    contrato.setTipo(TC.cb_tipo.getSelectedItem().toString());
                                    contrato.setStatus(TC.cbStatus.getSelectedItem().toString());
                                    cDAO.cadastrarContrato(contrato);                                    
                                } else if (e.getSource() == TC.Panel_Atualizar) {
                                    TelaAtualizarContratoVIEW TAC = new TelaAtualizarContratoVIEW();
                                    TAC.setVisible(true);
                                    TC.dispose();
                                    if (e.getSource() == TAC.label_lupa) {
                                        Contrato c = cDAO.pesquisarContratosporCPFIndividual();
                                        if (c.getCpf_Funcionario() == TAC.ftCPF.getText()) {
                                            preencheCamposContrato(TAC);
                                            if (e.getSource() == TAC.Panel_Atualizar) {
                                                cDAO.atualizarContrato(c);
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Esse CPF não existe");
                                        }
                                    } else if (e.getSource() == TAC.Panel_excluir) {
                                        TelaExcluirContratoVIEW TEC = new TelaExcluirContratoVIEW();
                                        TEC.setVisible(true);
                                        TAC.dispose();
                                        
                                        if (e.getSource() == TEC.label_lupa) {
                                            ArrayList<Contrato> contratos = cDAO.pesquisarContratoporCPF();
                                            for (int i = 0; i < contratos.size(); i++) {
                                                if (contratos.get(i).getCpf_Funcionario() == TEC.ftCPF.getText()) {
                                                    preencheTabelaContrato(TEC.tbContrato);
                                                    
                                                }
                                                
                                            }
                                            if (e.getSource() == TEC.Panel_Excluir) {
                                                if (TEC.txtIdContrato.getText().isEmpty()) {
                                                    JOptionPane.showMessageDialog(null, "Digite o id do Contrato");
                                                } else {
                                                    cDAO.excluirContrato(contratos);
                                                }
                                                
                                            }
                                            
                                        }
                                        
                                    }
                                    
                                }
                                
                            }
                        }
                    }
                }
            }
        }
    }

    public void preencheTabelaCompleta(JTable tabela) {
        DefaultTableModel tabelado = new DefaultTableModel();
        tabela.setModel(tabelado);
        
        tabelado.addColumn("Nome");
        tabelado.addColumn("CPF");
        tabelado.addColumn("RG");
        tabelado.addColumn("Nascimento");
        tabelado.addColumn("Sexo");
        tabelado.addColumn("Endereco");
        tabelado.addColumn("Bairro");
        tabelado.addColumn("Complemento");
        tabelado.addColumn("Número");
        tabelado.addColumn("CEP");
        tabelado.addColumn("Cidade");
        tabelado.addColumn("Estado");
        tabelado.addColumn("Celular");
        tabelado.addColumn("Telefone");
        tabelado.addColumn("Email");
        
        Object[] coluna = new Object[15];
        ArrayList<Funcionario> funcionarios = fDAO.consultarFuncionario();
        for (int i = 0; i < funcionarios.size(); i++) {
            coluna[0] = funcionarios.get(i).getNome();
            coluna[1] = funcionarios.get(i).getCpf();
            coluna[2] = funcionarios.get(i).getRg();
            coluna[3] = funcionarios.get(i).getNascimento();
            coluna[4] = funcionarios.get(i).getSexo();
            coluna[5] = funcionarios.get(i).getEndereco();
            coluna[6] = funcionarios.get(i).getBairro();
            coluna[7] = funcionarios.get(i).getComplemento();
            coluna[8] = funcionarios.get(i).getNumero();
            coluna[9] = funcionarios.get(i).getCep();
            coluna[10] = funcionarios.get(i).getCidade();
            coluna[11] = funcionarios.get(i).getEstado();
            coluna[12] = funcionarios.get(i).getCelular();
            coluna[13] = funcionarios.get(i).getTelefone();
            coluna[14] = funcionarios.get(i).getEmail();
            
            tabelado.addRow(coluna);
            tabela.setModel(tabelado);
            
        }
        
    }
    
    public void preencheTabelaporCPF(JTable tabela) {
        DefaultTableModel tabelado = new DefaultTableModel();
        tabela.setModel(tabelado);
        
        tabelado.addColumn("Nome");
        tabelado.addColumn("CPF");
        tabelado.addColumn("RG");
        tabelado.addColumn("Nascimento");
        tabelado.addColumn("Sexo");
        tabelado.addColumn("Endereco");
        tabelado.addColumn("Bairro");
        tabelado.addColumn("Complemento");
        tabelado.addColumn("Número");
        tabelado.addColumn("CEP");
        tabelado.addColumn("Cidade");
        tabelado.addColumn("Estado");
        tabelado.addColumn("Celular");
        tabelado.addColumn("Telefone");
        tabelado.addColumn("Email");
        
        Object[] coluna = new Object[15];
        Funcionario funcionario = fDAO.consultarFuncionarioCpf();
        coluna[0] = funcionario.getNome();
        coluna[1] = funcionario.getCpf();
        coluna[2] = funcionario.getRg();
        coluna[3] = funcionario.getNascimento();
        coluna[4] = funcionario.getSexo();
        coluna[5] = funcionario.getEndereco();
        coluna[6] = funcionario.getBairro();
        coluna[7] = funcionario.getComplemento();
        coluna[8] = funcionario.getNumero();
        coluna[9] = funcionario.getCep();
        coluna[10] = funcionario.getCidade();
        coluna[11] = funcionario.getEstado();
        coluna[12] = funcionario.getCelular();
        coluna[13] = funcionario.getTelefone();
        coluna[14] = funcionario.getEmail();
        
        tabelado.addRow(coluna);
        tabela.setModel(tabelado);
        
    }
    
    public void preencheCamposFuncionario(TelaAtualizarFuncionarioVIEW TAF) {
        Funcionario funcionario = fDAO.consultarFuncionarioCpf();
        TAF.ftCPF.setText(funcionario.getCpf());
        TAF.ftCelular.setText(funcionario.getCelular());
        TAF.ftCep.setText(funcionario.getCep());
        TAF.ftNascimento.setText(funcionario.getNascimento());
        TAF.ftRg.setText(funcionario.getRg());
        TAF.ftTelefoneFixo.setText(funcionario.getTelefone());
        TAF.txtBairro.setText(funcionario.getBairro());
        TAF.txtCidade.setText(funcionario.getCidade());
        TAF.txtComplemento.setText(funcionario.getComplemento());
        TAF.txtEmail.setText(funcionario.getEmail());
        TAF.txtEndereco.setText(funcionario.getEndereco());
        TAF.txtNomeFuncionario.setText(funcionario.getNome());
        TAF.txtNumeroRua.setText(funcionario.getNumero());
        
    }
    
    public void preencheCamposEmpresa(TelaAtualizarEmpresaVIEW TAE) {
        Empresa empresa = eDAO.consultarEmpresa();
        TAE.ftCNPJ.setText(empresa.getCnpj());
        TAE.txtNomeFantasia.setText(empresa.getCelular());
        TAE.ftCep.setText(empresa.getCep());
        TAE.txtRamoEmpresa.setText(empresa.getRamoempresa());
        TAE.ftTelefoneFixo.setText(empresa.getTelefone());
        TAE.txtBairro.setText(empresa.getBairro());
        TAE.txtCidade.setText(empresa.getCidade());
        TAE.txtComplemento.setText(empresa.getComplemento());
        TAE.txtEmail.setText(empresa.getEmail());
        TAE.txtEndereco.setText(empresa.getEndereco());
        TAE.txtNomeEmpresa.setText(empresa.getNome());
        TAE.txtNumeroRua.setText(empresa.getNumero());
        TAE.ftCelular.setText(empresa.getNumero());
        
    }

    public void preencheCamposContrato(TelaAtualizarContratoVIEW TAC) {
        Contrato contrato = cDAO.pesquisarContratosporCPFIndividual();
        TAC.ftCPF.setText(contrato.getCpf_Funcionario());
        TAC.ftHoraInicial.setText(contrato.getHorariofinal());
        TAC.ftHoraFinal.setText(contrato.getDiaincial());
        TAC.txtIdContrato.setText(Integer.toString(contrato.getId()));
        TAC.txtLocal.setText(contrato.getLocalizacao());
        TAC.cbStatus.setSelectedItem(contrato.getStatus());
        TAC.cb_tipo.setSelectedItem(contrato.getTipo());
        
    }
    
    public void preencheTabelaContrato(JTable tabela) {
        DefaultTableModel tabelado = new DefaultTableModel();
        tabela.setModel(tabelado);
        
        tabelado.addColumn("NOME");
        tabelado.addColumn("CPF_FUNCIONARIO");
        tabelado.addColumn("CNPJ_EMPRESA");
        tabelado.addColumn("ID_CONTRATO");
        tabelado.addColumn("DIA_INICIAL");
        tabelado.addColumn("DIA_FINAL");
        tabelado.addColumn("HORARIO INICIAL");
        tabelado.addColumn("HORARIO FINAL");
        tabelado.addColumn("LOCALIZACAO");
        tabelado.addColumn("TIPO");
        tabelado.addColumn("CLAUSULA");
        tabelado.addColumn("STATUS");
        
        Object[] coluna = new Object[11];
        ArrayList<Contrato> contratos = cDAO.pesquisarContratoporCPF();
        for (int i = 0; i < contratos.size(); i++) {
            coluna[0] = contratos.get(i).getNomefuncionario();
            coluna[1] = contratos.get(i).getCpf_Funcionario();
            coluna[2] = contratos.get(i).getCnpj_Empresa();
            coluna[3] = contratos.get(i).getId();
            coluna[4] = contratos.get(i).getDiaincial();
            coluna[5] = contratos.get(i).getDiafinal();
            coluna[6] = contratos.get(i).getHorarioinicial();
            coluna[7] = contratos.get(i).getHorariofinal();
            coluna[8] = contratos.get(i).getLocalizacao();
            coluna[9] = contratos.get(i).getTipo();
            coluna[10] = contratos.get(i).getClausula();
            coluna[11] = contratos.get(i).getStatus();
            
            tabelado.addRow(coluna);
            tabela.setModel(tabelado);
            
        }
        
    }
    
}
