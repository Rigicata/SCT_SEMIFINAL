/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.ControllerFuncionario;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.Contrato;
import model.Funcionario;
import modelDAO.ContratoDAO;
import modelDAO.FuncionarioDAO;
import views.ViewsEmpresa.TelaLoginEmpresaVIEW;
import views.ViewsFuncionario.TelaConsultarContratoFuncionarioVIEW;
import views.ViewsFuncionario.TelaLoginFuncionarioVIEW;

/**
 *
 * @author aluno
 */
public class FuncionarioController extends MouseAdapter {

    TelaLoginFuncionarioVIEW TLF = new TelaLoginFuncionarioVIEW();
    TelaConsultarContratoFuncionarioVIEW TCCF = new TelaConsultarContratoFuncionarioVIEW();
    FuncionarioDAO fDAO = new FuncionarioDAO();
    ContratoDAO cDAO = new ContratoDAO();
    

    public FuncionarioController(TelaLoginFuncionarioVIEW TLF,  TelaConsultarContratoFuncionarioVIEW TCCF ) {
        this.TLF = TLF;
        TLF.Painel_Entrar.addMouseListener(this);
        this.TCCF = TCCF;

    }

    @Override

    public void mouseClicked(MouseEvent e) {
        ArrayList<Funcionario> funcionarios = fDAO.verificarLogin();
        if (e.getSource() == TLF.Painel_Entrar) {
            for (int i = 0; i < funcionarios.size(); i++) {
                if (funcionarios.get(i).getCpf().equals(TLF.ftCPF.getText()) && funcionarios.get(i).getSenha().equals(TLF.txtSenha.getPassword())) {
                    TCCF.setVisible(true);
                    this.TLF.dispose();
                    

                }else {
                    JOptionPane.showMessageDialog(null, "Login ou senha incorretos");
                    
                }
            }
            
            
            if(e.getSource()==TCCF.label_PesquisarCPF){
                preencheTabelaporCPF(TCCF.tb_Funcionario);
            } else if(e.getSource()==TCCF.label_PesquisaridContrato) {
                preencheTabelaporID(TCCF.tb_Funcionario);
                
            }
            
            
           

        }

    }
    
    
    public void preencheTabelaporCPF(JTable tabela){ 
    DefaultTableModel tabelado = new DefaultTableModel();
    tabela.setModel(tabelado);
    
        tabelado.addColumn("ID Contrato");
        tabelado.addColumn("CNPJ(EMPRESA)");
        tabelado.addColumn("CPF");
        tabelado.addColumn("Dia Inicial");
        tabelado.addColumn("Dia Final");
        tabelado.addColumn("Horário Inicial");
        tabelado.addColumn("Horário Final");
        tabelado.addColumn("Localização");
        tabelado.addColumn("Tipo");
        tabelado.addColumn("Cláusulas");
        Object[] coluna = new Object[10];
        ArrayList<Contrato> contratos = cDAO.pesquisarContratoporCPF();
        for(int i=0;i<contratos.size();i++){
            coluna[0] = contratos.get(i).getId();
            coluna[1] = contratos.get(i).getCnpj_Empresa();
            coluna[2] = contratos.get(i).getCpf_Funcionario();
            coluna[3] = contratos.get(i).getDiaincial();
            coluna[4] = contratos.get(i).getDiafinal();
            coluna[5] = contratos.get(i).getHorarioinicial();
            coluna[6] = contratos.get(i).getHorariofinal();
            coluna[7] = contratos.get(i).getLocalizacao();
            coluna[8] = contratos.get(i).getTipo();
            coluna[9] = contratos.get(i).getClausula();
           
            
           tabelado.addRow(coluna);
           tabela.setModel(tabelado);
              
              
          }
    }


        
    public void preencheTabelaporID(JTable tabela){
         DefaultTableModel tabelado = new DefaultTableModel();
         tabela.setModel(tabelado);
        tabelado.addColumn("ID Contrato");
        tabelado.addColumn("CNPJ(EMPRESA)");
        tabelado.addColumn("CPF");
        tabelado.addColumn("Dia Inicial");
        tabelado.addColumn("Dia Final");
        tabelado.addColumn("Horário Inicial");
        tabelado.addColumn("Horário Final");
        tabelado.addColumn("Localização");
        tabelado.addColumn("Tipo");
        tabelado.addColumn("Horário Inicial");
        Object[] coluna = new Object[10];
        Contrato listarContrato = cDAO.pesquisarContratosporIdContrato();
            coluna[0] =listarContrato.getId();
            coluna[1] = listarContrato.getCnpj_Empresa();
            coluna[2] = listarContrato.getCpf_Funcionario();
            coluna[3] =listarContrato.getDiaincial();
            coluna[4] = listarContrato.getDiafinal();
            coluna[5] = listarContrato.getHorarioinicial();
            coluna[6] = listarContrato.getHorariofinal();
            coluna[7] = listarContrato.getLocalizacao();
            coluna[8] = listarContrato.getTipo();
            coluna[9] = listarContrato.getClausula();
           
            
           tabelado.addRow(coluna);
          tabela.setModel(tabelado);
        
        
        
    }
    
    
       
       
            
        }
   
            
      


