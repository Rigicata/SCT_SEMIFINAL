/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Conexao;
import model.Contrato;

/**
 *
 * @author aluno
 */
public class ContratoDAO {

    Conexao conexao;
    PreparedStatement pst;

    public ContratoDAO() {
        this.conexao = new Conexao();

    }

    public void cadastrarContrato(Contrato contrato) {
        try {
            Connection conecta = this.conexao.conector();
            String sql = "insert into contrato(dia_Inicial,dia_Fim,horario_Inicio,horario_Final,localizacao,tipo,clausula,funcionario_Status)"
                    + "values(?,?,?,?,?,?,?,?)"; //Script para o banco

            pst = conecta.prepareCall(sql); //Passando o script para o banco

            //Cadastro das informações
            pst.setString(1, contrato.getDiafinal());
            pst.setString(2, contrato.getDiaincial());
            pst.setString(3, contrato.getHorariofinal());
            pst.setString(4, contrato.getHorarioinicial());
            pst.setString(5, contrato.getLocalizacao());
            pst.setString(6, contrato.getTipo());
            pst.setString(7, contrato.getClausula());
            pst.setInt(8, contrato.getId());
            pst.setString(9, contrato.getStatus());
            pst.setString(10, contrato.getCnpj_Empresa());
            pst.setString(11, contrato.getCpf_Funcionario());
            pst.executeUpdate(); // Fazendo o Uptade no banco

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro no banco:" + e.getMessage());

        }
    }

    public ArrayList<Contrato> pesquisarContratoporCPF() {
        String sql = "select*from contrato where cpf_Funcionario=?";
        ArrayList<Contrato> contratos = new ArrayList<>();
        Contrato contrato;

        try {
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                contrato = new Contrato();
                contrato.setClausula(rs.getString("clausula"));
                contrato.setDiafinal(rs.getString("dia_Final"));
                contrato.setDiaincial(rs.getString("dia_Inicial"));
                contrato.setHorariofinal(rs.getString("horario_Final"));
                contrato.setHorarioinicial(rs.getString("horario_Inicial"));
                contrato.setId((rs.getInt("id")));
                contrato.setLocalizacao(rs.getString("localizacao"));
                contrato.setTipo(rs.getString("tipo"));
                contrato.setCnpj_Empresa("cnpj_Empresa");
                contrato.setCpf_Funcionario("cpf_Funcionario");
                contratos.add(contrato);

            }

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }

        return contratos;
    }

    public void excluirContrato(ArrayList<Contrato>contratos) {

        try {
            Connection conecta = this.conexao.conector();
            String sql = "delete from contrato where idContrato=?";
            pst = conecta.prepareCall(sql);

            //Excluindo das informações
            for(int i=0;i<contratos.size();i++){
                 pst.setString(1, contratos.get(i).getDiafinal());
                 pst.setString(2, contratos.get(i).getDiaincial());
                 pst.setString(3, contratos.get(i).getHorariofinal());
                 pst.setString(4, contratos.get(i).getHorarioinicial());
                 pst.setString(5, contratos.get(i).getLocalizacao());
            pst.setString(6, contratos.get(i).getTipo());
            pst.setString(7, contratos.get(i).getClausula());
            pst.setInt(8, contratos.get(i).getId());
            pst.setString(9, contratos.get(i).getStatus());
            pst.setString(10, contratos.get(i).getCnpj_Empresa());
            pst.setString(11, contratos.get(i).getCpf_Funcionario());
            }
           

            pst.executeUpdate(); // Fazendo o Uptade no banco

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro no banco: " + e.getMessage());

        }

    }

    public void atualizarContrato(Contrato contrato) {
        String sql = "update from contrato set dia_Inicial=?,dia_Fim=?,horario_Inicio=?,horario_Final=?,localizacao=?,tipo=?,clausula=?,funcionario_Status=?";

        try {
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql); //Passando o script para o banco

            //Cadastro das informações
            pst.setString(1, contrato.getClausula());
            pst.setString(2, contrato.getDiafinal());
            pst.setString(3, contrato.getDiaincial());
            pst.setString(4, contrato.getHorariofinal());
            pst.setString(5, contrato.getHorarioinicial());
            pst.setString(6, contrato.getLocalizacao());
            pst.setString(7, contrato.getTipo());
            pst.setInt(8, contrato.getId());
            pst.setString(9, contrato.getStatus());
            pst.setString(10, contrato.getCnpj_Empresa());
            pst.setString(11, contrato.getCpf_Funcionario());

            pst.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro no banco:" + e.getMessage());

        }

    }

    public Contrato pesquisarContratosporIdContrato() {

        String sql = "select*from contrato where idContrato=? and cpf_Funcionario=?";

        Contrato contrato = null;

        try {
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                contrato = new Contrato();
                contrato.setClausula(rs.getString("clausula"));
                contrato.setDiafinal(rs.getString("dia_Final"));
                contrato.setDiaincial(rs.getString("dia_Inicial"));
                contrato.setHorariofinal(rs.getString("horario_Final"));
                contrato.setHorarioinicial(rs.getString("horario_Inicial"));
                contrato.setId((rs.getInt("id")));
                contrato.setLocalizacao(rs.getString("localizacao"));
                contrato.setTipo(rs.getString("tipo"));
                contrato.setStatus(rs.getString("funcionario_Status"));
                contrato.setCnpj_Empresa("cnpj_Empresa");
                contrato.setCpf_Funcionario("cpf_Funcionario");

            }

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }

        return contrato;
    }
    
  public Contrato pesquisarContratosporCPFIndividual() {

        String sql = "select*from contrato where cpf_Funcionario=?";

        Contrato contrato = null;

        try {
            Connection conecta = this.conexao.conector();
            pst = conecta.prepareCall(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                contrato = new Contrato();
                contrato.setClausula(rs.getString("clausula"));
                contrato.setDiafinal(rs.getString("dia_Final"));
                contrato.setDiaincial(rs.getString("dia_Inicial"));
                contrato.setHorariofinal(rs.getString("horario_Final"));
                contrato.setHorarioinicial(rs.getString("horario_Inicial"));
                contrato.setId((rs.getInt("id")));
                contrato.setLocalizacao(rs.getString("localizacao"));
                contrato.setTipo(rs.getString("tipo"));
                contrato.setStatus(rs.getString("funcionario_Status"));
               

            }

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }

        return contrato;
    }
    

}


