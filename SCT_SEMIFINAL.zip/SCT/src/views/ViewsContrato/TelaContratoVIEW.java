/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views.ViewsContrato;


import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import views.ViewsEmpresa.TelaMenuEmpresaVIEW;



/**
 *
 * @author Maresia-
 */
public class TelaContratoVIEW extends javax.swing.JFrame {

    
    
    
    public TelaContratoVIEW() {
        initComponents();
        
        
    }
    
    //////////PARTE Termo de Uso ////////////////////////////////////////
public void setColorBtn(JPanel panel){

    panel.setBackground(new java.awt.Color(0,102,102));
}

public void resetColorBtn(JPanel panel){
 
    panel.setBackground(new java.awt.Color(19,19,70));

}
/////////////////////////////////////////////////////////////////////  
    



   
   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        label_Empresa = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Panel_Voltar = new javax.swing.JPanel();
        label_Voltar = new javax.swing.JLabel();
        Panel_Cadastrar = new javax.swing.JPanel();
        label_Cadastrar = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        txtIdContrato = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        ftCNPJ = new javax.swing.JFormattedTextField();
        label_CNPJ = new javax.swing.JLabel();
        label_CNPJ1 = new javax.swing.JLabel();
        label_CNPJ2 = new javax.swing.JLabel();
        ftCPF = new javax.swing.JFormattedTextField();
        jSeparator5 = new javax.swing.JSeparator();
        label_CNPJ3 = new javax.swing.JLabel();
        label_CNPJ4 = new javax.swing.JLabel();
        djDiaFinal = new com.toedter.calendar.JDateChooser();
        djDiaInicial = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtClausula = new javax.swing.JTextArea();
        label_CNPJ5 = new javax.swing.JLabel();
        ftHoraInicial = new javax.swing.JFormattedTextField();
        ftHoraFinal = new javax.swing.JFormattedTextField();
        label_CNPJ6 = new javax.swing.JLabel();
        label_CNPJ7 = new javax.swing.JLabel();
        label_CNPJ8 = new javax.swing.JLabel();
        txtLocal = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        cb_tipo = new javax.swing.JComboBox<>();
        label_Celular2 = new javax.swing.JLabel();
        Panel_Atualizar = new javax.swing.JPanel();
        label_Cadastrar1 = new javax.swing.JLabel();
        label_Celular3 = new javax.swing.JLabel();
        cbStatus = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(19, 19, 70));

        label_Empresa.setBackground(new java.awt.Color(240, 255, 255));
        label_Empresa.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Empresa.setForeground(new java.awt.Color(240, 255, 255));
        label_Empresa.setText("CADASTRAR CONTRATO");

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons8-aperto-de-mão-40.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(label_Empresa)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 501, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(label_Empresa)
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 80));

        jPanel2.setBackground(new java.awt.Color(240, 255, 255));

        Panel_Voltar.setBackground(new java.awt.Color(19, 19, 70));
        Panel_Voltar.setToolTipText("VOLTAR");
        Panel_Voltar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Panel_Voltar.setPreferredSize(new java.awt.Dimension(130, 44));
        Panel_Voltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Panel_VoltarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Panel_VoltarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Panel_VoltarMouseExited(evt);
            }
        });

        label_Voltar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Voltar.setForeground(new java.awt.Color(240, 255, 255));
        label_Voltar.setText("VOLTAR");

        javax.swing.GroupLayout Panel_VoltarLayout = new javax.swing.GroupLayout(Panel_Voltar);
        Panel_Voltar.setLayout(Panel_VoltarLayout);
        Panel_VoltarLayout.setHorizontalGroup(
            Panel_VoltarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 129, Short.MAX_VALUE)
            .addGroup(Panel_VoltarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_VoltarLayout.createSequentialGroup()
                    .addContainerGap(28, Short.MAX_VALUE)
                    .addComponent(label_Voltar)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );
        Panel_VoltarLayout.setVerticalGroup(
            Panel_VoltarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
            .addGroup(Panel_VoltarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_VoltarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Voltar)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        Panel_Cadastrar.setBackground(new java.awt.Color(19, 19, 70));
        Panel_Cadastrar.setToolTipText("CADASTRAR");
        Panel_Cadastrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Panel_Cadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Panel_CadastrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Panel_CadastrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Panel_CadastrarMouseExited(evt);
            }
        });

        label_Cadastrar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Cadastrar.setForeground(new java.awt.Color(240, 255, 255));
        label_Cadastrar.setText("CADASTRAR");

        javax.swing.GroupLayout Panel_CadastrarLayout = new javax.swing.GroupLayout(Panel_Cadastrar);
        Panel_Cadastrar.setLayout(Panel_CadastrarLayout);
        Panel_CadastrarLayout.setHorizontalGroup(
            Panel_CadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 130, Short.MAX_VALUE)
            .addGroup(Panel_CadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_CadastrarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        Panel_CadastrarLayout.setVerticalGroup(
            Panel_CadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
            .addGroup(Panel_CadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_CadastrarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jSeparator1.setBackground(new java.awt.Color(19, 19, 70));
        jSeparator1.setForeground(new java.awt.Color(19, 19, 70));
        jSeparator1.setOpaque(true);

        txtIdContrato.setBackground(new java.awt.Color(240, 255, 255));
        txtIdContrato.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        txtIdContrato.setToolTipText("NOME DA EMPRESA");
        txtIdContrato.setBorder(null);

        jSeparator3.setBackground(new java.awt.Color(19, 19, 70));
        jSeparator3.setForeground(new java.awt.Color(19, 19, 70));
        jSeparator3.setOpaque(true);

        ftCNPJ.setBackground(new java.awt.Color(240, 255, 255));
        ftCNPJ.setBorder(null);
        try {
            ftCNPJ.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##.###.###/####-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        ftCNPJ.setToolTipText("CNPJ");

        label_CNPJ.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ.setText("CNPJ");

        label_CNPJ1.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ1.setText("ID CONTRATO");

        label_CNPJ2.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ2.setText("CPF");

        ftCPF.setBackground(new java.awt.Color(240, 255, 255));
        ftCPF.setBorder(null);
        try {
            ftCPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        ftCPF.setToolTipText("CNPJ");

        jSeparator5.setBackground(new java.awt.Color(19, 19, 70));
        jSeparator5.setForeground(new java.awt.Color(19, 19, 70));
        jSeparator5.setOpaque(true);

        label_CNPJ3.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ3.setText("DATA INICIAL");

        label_CNPJ4.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ4.setText("DATA FINAL");

        djDiaFinal.setBackground(new java.awt.Color(240, 255, 255));
        djDiaFinal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        djDiaInicial.setBackground(new java.awt.Color(240, 255, 255));
        djDiaInicial.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        txtClausula.setColumns(20);
        txtClausula.setRows(5);
        jScrollPane1.setViewportView(txtClausula);

        label_CNPJ5.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ5.setText("CLÁUSULA");

        try {
            ftHoraInicial.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        try {
            ftHoraFinal.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        label_CNPJ6.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ6.setText("INÍCIO ÀS");

        label_CNPJ7.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ7.setText("TÉRMINO ÀS");

        label_CNPJ8.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_CNPJ8.setText("LOCAL");

        txtLocal.setBackground(new java.awt.Color(240, 255, 255));
        txtLocal.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        txtLocal.setToolTipText("ENDEREÇO");
        txtLocal.setBorder(null);
        txtLocal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLocalActionPerformed(evt);
            }
        });

        jSeparator4.setBackground(new java.awt.Color(19, 19, 70));
        jSeparator4.setForeground(new java.awt.Color(19, 19, 70));
        jSeparator4.setOpaque(true);

        cb_tipo.setBackground(new java.awt.Color(19, 19, 70));
        cb_tipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " CONSTRUÇÃO", " MANUTENÇÃO", " MONTAGEM" }));
        cb_tipo.setBorder(null);
        cb_tipo.setOpaque(false);
        cb_tipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_tipoActionPerformed(evt);
            }
        });

        label_Celular2.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_Celular2.setText("TIPO");

        Panel_Atualizar.setBackground(new java.awt.Color(19, 19, 70));
        Panel_Atualizar.setToolTipText("ATUALIZAR");
        Panel_Atualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Panel_Atualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Panel_AtualizarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Panel_AtualizarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Panel_AtualizarMouseExited(evt);
            }
        });

        label_Cadastrar1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Cadastrar1.setForeground(new java.awt.Color(240, 255, 255));
        label_Cadastrar1.setText("ATUALIZAR");

        javax.swing.GroupLayout Panel_AtualizarLayout = new javax.swing.GroupLayout(Panel_Atualizar);
        Panel_Atualizar.setLayout(Panel_AtualizarLayout);
        Panel_AtualizarLayout.setHorizontalGroup(
            Panel_AtualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 129, Short.MAX_VALUE)
            .addGroup(Panel_AtualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_AtualizarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar1)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        Panel_AtualizarLayout.setVerticalGroup(
            Panel_AtualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
            .addGroup(Panel_AtualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_AtualizarLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_Cadastrar1)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        label_Celular3.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        label_Celular3.setText("STATUS");

        cbStatus.setBackground(new java.awt.Color(19, 19, 70));
        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "EM ANDAMENTO" }));
        cbStatus.setEnabled(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Panel_Voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Panel_Atualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(184, 184, 184)
                        .addComponent(Panel_Cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtIdContrato, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(label_CNPJ, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(ftCNPJ, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(label_CNPJ1))
                                .addGap(70, 70, 70)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(label_CNPJ3)
                                    .addComponent(djDiaFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(djDiaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(label_CNPJ4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 93, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(label_CNPJ8)
                                    .addComponent(txtLocal, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(label_CNPJ2)
                                        .addComponent(jSeparator5)
                                        .addComponent(ftCPF, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(label_CNPJ6)
                                            .addComponent(ftHoraInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(32, 32, 32)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(ftHoraFinal, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE)
                                            .addComponent(label_CNPJ7)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(label_Celular2)
                                            .addComponent(cb_tipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(label_Celular3)
                                            .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(19, 19, 19)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label_CNPJ5)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(72, 72, 72))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(label_CNPJ5)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label_CNPJ1)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(label_CNPJ3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(txtIdContrato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(4, 4, 4)
                                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(34, 34, 34)
                                        .addComponent(label_CNPJ)
                                        .addGap(11, 11, 11)
                                        .addComponent(ftCNPJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(djDiaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(33, 33, 33)
                                        .addComponent(label_CNPJ4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(djDiaFinal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(40, 40, 40)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(label_CNPJ2)
                                .addGap(11, 11, 11)
                                .addComponent(ftCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(5, 5, 5)
                                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(label_CNPJ7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ftHoraFinal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(label_CNPJ6)
                                .addGap(8, 8, 8)
                                .addComponent(ftHoraInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(label_CNPJ8)
                                .addGap(7, 7, 7)
                                .addComponent(txtLocal, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(label_Celular2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cb_tipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(label_Celular3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Panel_Voltar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Panel_Cadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Panel_Atualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(204, 204, 204))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 74, 870, 650));

        setSize(new java.awt.Dimension(855, 599));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Panel_CadastrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_CadastrarMouseEntered
     setColorBtn(Panel_Cadastrar);
    }//GEN-LAST:event_Panel_CadastrarMouseEntered

    private void Panel_CadastrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_CadastrarMouseExited
      resetColorBtn(Panel_Cadastrar);
    }//GEN-LAST:event_Panel_CadastrarMouseExited

    private void Panel_VoltarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_VoltarMouseEntered
      setColorBtn(Panel_Voltar);
    }//GEN-LAST:event_Panel_VoltarMouseEntered

    private void Panel_VoltarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_VoltarMouseExited
      resetColorBtn(Panel_Voltar);
    }//GEN-LAST:event_Panel_VoltarMouseExited

    private void Panel_CadastrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_CadastrarMouseClicked
       
    }//GEN-LAST:event_Panel_CadastrarMouseClicked

    private void Panel_VoltarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_VoltarMouseClicked
     TelaMenuEmpresaVIEW tmev = new TelaMenuEmpresaVIEW();
     tmev.setVisible(true);
     this.dispose();
    }//GEN-LAST:event_Panel_VoltarMouseClicked

    private void Panel_AtualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_AtualizarMouseClicked
      TelaExcluirContratoVIEW tacv = new TelaExcluirContratoVIEW();
      tacv.setVisible(true);
      this.dispose();
    }//GEN-LAST:event_Panel_AtualizarMouseClicked

    private void Panel_AtualizarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_AtualizarMouseEntered
        setColorBtn(Panel_Atualizar);
    }//GEN-LAST:event_Panel_AtualizarMouseEntered

    private void Panel_AtualizarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Panel_AtualizarMouseExited
        resetColorBtn(Panel_Atualizar);
    }//GEN-LAST:event_Panel_AtualizarMouseExited

    private void cb_tipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_tipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_tipoActionPerformed

    private void txtLocalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLocalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLocalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
     
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaContratoVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaContratoVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaContratoVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaContratoVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                new TelaContratoVIEW().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JPanel Panel_Atualizar;
    public javax.swing.JPanel Panel_Cadastrar;
    private javax.swing.JPanel Panel_Voltar;
    public javax.swing.JComboBox<String> cbStatus;
    public javax.swing.JComboBox<String> cb_tipo;
    public com.toedter.calendar.JDateChooser djDiaFinal;
    public com.toedter.calendar.JDateChooser djDiaInicial;
    public javax.swing.JFormattedTextField ftCNPJ;
    public javax.swing.JFormattedTextField ftCPF;
    public javax.swing.JFormattedTextField ftHoraFinal;
    public javax.swing.JFormattedTextField ftHoraInicial;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel label_CNPJ;
    private javax.swing.JLabel label_CNPJ1;
    private javax.swing.JLabel label_CNPJ2;
    private javax.swing.JLabel label_CNPJ3;
    private javax.swing.JLabel label_CNPJ4;
    private javax.swing.JLabel label_CNPJ5;
    private javax.swing.JLabel label_CNPJ6;
    private javax.swing.JLabel label_CNPJ7;
    private javax.swing.JLabel label_CNPJ8;
    private javax.swing.JLabel label_Cadastrar;
    private javax.swing.JLabel label_Cadastrar1;
    private javax.swing.JLabel label_Celular2;
    private javax.swing.JLabel label_Celular3;
    private javax.swing.JLabel label_Empresa;
    private javax.swing.JLabel label_Voltar;
    public javax.swing.JTextArea txtClausula;
    public javax.swing.JTextField txtIdContrato;
    public javax.swing.JTextField txtLocal;
    // End of variables declaration//GEN-END:variables
}
